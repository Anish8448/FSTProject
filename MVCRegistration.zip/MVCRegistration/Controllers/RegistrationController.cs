﻿using Microsoft.AspNetCore.Mvc;
using MVCRegistration.Models;
using System.Linq;
//using System;
//using MVCRegistration.Models;

namespace MVCRegistration.Controllers
{
    public class RegistrationController : Controller
    {
        private readonly Registration_context register;
        public RegistrationController(Registration_context rc)
        {
            register = rc;

        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult SetData()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SetData(Registration us)
        {
            
            register.Add(us);
            register.SaveChanges();
            ViewData["message"] = "The user" + us.r_name + " details is saved successfully.";

                   
            return View();
        }

        public IActionResult ShowData()
        {
            var obj = register.mvcreg.ToList();
            
            
            
            return View(obj);
        }

        [HttpGet]
        public IActionResult Delete()
        {

            return View();
        }

        [HttpDelete]
        public IActionResult Delete(int sid)
        {
            if (sid > 0)
            {
                var byid = register.mvcreg.Where(x => x.id == sid).FirstOrDefault() ;
                    register.SaveChanges();
                if (byid != null)
                {
                    register.mvcreg.Remove(byid);
                    register.SaveChanges();
                    return RedirectToAction("ShowData");
                }
            }
            return View();
        }

        public IActionResult Update()
        {
            return View();
        }
    }
}
