﻿using Microsoft.EntityFrameworkCore;

namespace MVCRegistration.Models
{
    public class Registration_context: DbContext
    {
        public Registration_context(DbContextOptions<Registration_context> options) : base(options)
        {

        }
        public DbSet<Registration> mvcreg { get; set; } 
    }
}
