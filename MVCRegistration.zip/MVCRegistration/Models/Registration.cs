﻿
using System.ComponentModel.DataAnnotations;
    namespace MVCRegistration.Models
{
    public class Registration
    {
        [Key]
        public int id { get; set; }

        [Required(ErrorMessage ="Name is required")]
        public string r_name { get; set; }

        [Required(ErrorMessage ="Email is required")]
        public string r_email { get; set; } 
        
        [Required(ErrorMessage ="Mobile no is required")]
        [Range(1000000000,9999999999, ErrorMessage ="Mobile No. must be of 10 digits")]
        public long r_mobile { get; set; }

    }
}
